load cir_x_test_49G1G_1_1

cir_all = cir_x_test_49G1G_1_1;
Tx_gain=15;
Rx_gain=15;
sps=2;
samp_rate=1250e6;  
for j = 1:100
cir_pow = cir_all(:,j);
rec_pow=20*log10(abs(cir_pow))-Tx_gain-Rx_gain;%%接收功率
rece_pow_all(:,j) = rec_pow;
end
figure;
t_scale=(1:length(rec_pow))/samp_rate*sps*1e6;
snapshot = [1:1:100]./10;
[X,Y] = meshgrid(snapshot,t_scale);
s = pcolor(Y,X,rece_pow_all(:,:))
caxis([ -105 -95]);
c = colorbar;
c.Label.String = 'Power (dBm)';
c.Label.FontSize = 12;
cm = colormap(jet); 
colormap(cm(1:1:end,:));
shading flat
s.FaceColor='interp'
c = colorbar;
title(c, 'dBm', 'FontSize', 12); % 将标题放在 colorbar 上方
cm = colormap(jet);
colormap(cm(1:1:end,:));
ylabel('Distance (m)');
xlabel('Delay, \tau (us)');
