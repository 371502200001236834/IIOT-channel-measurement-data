load DS_x_test_49G1G_1_1.mat
load DS_m_test_49G1G_1_1.mat

% 确保数据为列向量
K_all_49G_x = DS_x_test_49G1G_1_1(:);
K_all_49G_m = DS_m_test_49G1G_1_1(:);

% 将数据中的负数转换为绝对值
K_all_49G_x_abs = abs(K_all_49G_x);
K_all_49G_m_abs = abs(K_all_49G_m);

% 过滤掉非正值数据
K_all_49G_x_filtered = K_all_49G_x_abs(K_all_49G_x_abs > 0);
K_all_49G_m_filtered = K_all_49G_m_abs(K_all_49G_m_abs > 0);
% 过滤掉无穷大和负无穷大的值
%K_all_49G_x_filtered = K_all_49G_x_filtered(~isinf(K_all_49G_x_filtered));
%K_all_49G_m_filtered = K_all_49G_m_filtered(~isinf(K_all_49G_m_filtered));
% 计算两个数据集的CDF
[f1_x, H1_x] = ecdf(K_all_49G_x_filtered); % 计算场景x的CDF
[f1_m, H1_m] = ecdf(K_all_49G_m_filtered); % 计算场景m的CDF

% 定义显示点的间隔
interval = 3;

% 绘制原始数据的CDF曲线，使用间隔取点
figure
plot(H1_x(1:interval:end), f1_x(1:interval:end), 'g-o', 'linewidth', 1.5) % 4.9GHz 场景x，用绿色圆圈
hold on;
plot(H1_m(1:interval:end), f1_m(1:interval:end), 'r-*', 'linewidth', 1.5) % 4.9GHz 场景m，用红色星号

% 对场景x的数据拟合对数正态分布
pd_lognormal_x = fitdist(K_all_49G_x_filtered, 'Lognormal');
x_values_x = linspace(min(H1_x), max(H1_x), 100);
y_lognormal_x = cdf(pd_lognormal_x, x_values_x);
plot(x_values_x, y_lognormal_x, 'k:', 'LineWidth', 1.5); % 场景x的对数正态分布拟合，用蓝色虚线

% 对场景m的数据拟合正态分布
pd_normal_m = fitdist(K_all_49G_m_filtered, 'Normal');
x_values_m = linspace(min(H1_m), max(H1_m), 100);
y_normal_m = cdf(pd_normal_m, x_values_m);
plot(x_values_m, y_normal_m, 'k--', 'LineWidth', 1.5); % 场景m的正态分布拟合，用黑色点划线

% 设置图形属性
xlabel('\sigma_\tau (us)', 'FontSize', 12, 'FontName', 'times new roman');
ylabel('CDF', 'FontSize', 12, 'FontName', 'times new roman');
legend('Sparse measurements', 'Dense measurements', 'Fitted sparse measurements', 'Fitted dense measurements');
grid on;
hold off;